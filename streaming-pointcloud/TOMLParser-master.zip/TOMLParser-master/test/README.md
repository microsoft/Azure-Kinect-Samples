testing programs
====

files listed below is copied and a bit modified from
[toml-lang/toml](https://github.com/toml-lang/toml) 
tests directory in order to test my codes.

* example.toml
* hard\_example.toml
* hard\_example\_unicode.toml
* hard\_example\_error1.toml
* hard\_example\_error2.toml
* hard\_example\_error3.toml


