#ifndef CPP_TOML_PARSER
#define CPP_TOML_PARSER

#include "src/toml_parser.hpp"
#include "src/get.hpp"

#endif /* CPP_TOML_PARSER */
